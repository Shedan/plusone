<?php
/**
 * Silence is Golden.
 *
 * @package Convert Plus.
 */

// Silence is golden and we totally agree.

