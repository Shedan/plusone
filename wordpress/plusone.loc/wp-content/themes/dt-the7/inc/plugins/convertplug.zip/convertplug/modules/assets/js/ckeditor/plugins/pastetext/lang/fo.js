﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'pastetext', 'fo', {
	button: 'Innrita som reinan tekst',
	title: 'Innrita som reinan tekst'
} );
